DENSITY_FILEs = ["M4_spatialSplitParam4.csv","M4_spatialSplitParam8.csv","M4vsBase_moveParam4.csv"]
UTILITY_FILEs = ["UtilityVsRuntime.csv"]

import matplotlib.pyplot as plt
import pandas as pd
plt.rcParams.update({'font.size': 20})


for INPUT_FILE in DENSITY_FILEs:
    df = pd.read_csv(INPUT_FILE)
    df.plot(x = 'Time')
    plt.grid(b=True, which='major', color='#666666', linestyle='-')
    plt.minorticks_on()
    plt.grid(b=True, which='minor', color='#999999', linestyle='-', alpha=0.2)
    fig1 = plt.gcf()
    fig1.set_size_inches(20, 10)
    plt.savefig(INPUT_FILE[:-4]+".jpg")

for INPUT_FILE in UTILITY_FILEs:
    df = pd.read_csv(INPUT_FILE)
    if len(df.columns) == 4:
        ax = df.plot.scatter(y = 'RunTime', x = 'QueueUtility')
        df.apply(lambda r: ax.annotate(r['Parameter'].astype(str), (r.QueueUtility, r.RunTime)), axis=1)
        plt.xlim(0,100)
        plt.ylim(12,30)
        plt.grid(b=True, which='major', color='#666666', linestyle='-')
        plt.minorticks_on()
        plt.grid(b=True, which='minor', color='#999999', linestyle='-', alpha=0.2)
        fig1 = plt.gcf()
        fig1.set_size_inches(15, 10)
        plt.savefig(INPUT_FILE[:-4]+"Queue.jpg")
        ax = df.plot.scatter(y = 'RunTime', x = 'MovingUtility')
        df.apply(lambda r: ax.annotate(r['Parameter'].astype(str), (r.MovingUtility, r.RunTime)), axis=1)
        plt.xlim(0,100)
        plt.ylim(12,30)
        plt.grid(b=True, which='major', color='#666666', linestyle='-')
        plt.minorticks_on()
        plt.grid(b=True, which='minor', color='#999999', linestyle='-', alpha=0.2)
        fig1 = plt.gcf()
        fig1.set_size_inches(15, 10)
        plt.savefig(INPUT_FILE[:-4]+"Moving.jpg")
    if len(df.columns) == 5:
        ax = df.plot.scatter(y = 'RunTime', x = 'QueueUtility')
        df.apply(lambda r: ax.annotate("("+r['ParameterX'].astype(str)+","+r['ParameterY'].astype(str)+")", (r.QueueUtility, r.RunTime)), axis=1)
        plt.xlim(0,100)
        plt.ylim(12,30)
        plt.grid(b=True, which='major', color='#666666', linestyle='-')
        plt.minorticks_on()
        plt.grid(b=True, which='minor', color='#999999', linestyle='-', alpha=0.2)
        fig1 = plt.gcf()
        fig1.set_size_inches(15, 10)
        plt.savefig(INPUT_FILE[:-4]+"Queue.jpg")
        ax = df.plot.scatter(y = 'RunTime', x = 'MovingUtility')
        df.apply(lambda r: ax.annotate("("+r['ParameterX'].astype(str)+","+r['ParameterY'].astype(str)+")", (r.MovingUtility, r.RunTime)), axis=1)
        plt.xlim(0,100)
        plt.ylim(12,30)
        plt.grid(b=True, which='major', color='#666666', linestyle='-')
        plt.minorticks_on()
        plt.grid(b=True, which='minor', color='#999999', linestyle='-', alpha=0.2)
        fig1 = plt.gcf()
        fig1.set_size_inches(15, 10)
        plt.savefig(INPUT_FILE[:-4]+"Moving.jpg")

